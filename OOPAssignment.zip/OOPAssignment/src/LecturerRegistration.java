
import java.io.IOException;
import java.util.Random;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class LecturerRegistration {
    private static final String filename = "lecturer.txt";
    private LecturerFileHandler fileHandler;
     
public LecturerRegistration(){
    this.fileHandler = new LecturerFileHandler ();
}

public boolean registerLecturer (String Name, String Password, String Gender, String Role) throws IOException{
    if(Name.isEmpty() || Password.isEmpty() || Gender == null || Role == null){
        
        JOptionPane.showMessageDialog(null, "One or more mandatory fields is empty", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    Random rand = new Random();
    String lecturerID = "LT"+rand.nextInt(1000);
    
    Lecturer newLecturer = new Lecturer(lecturerID, Name, Password, Gender);
    
    if (fileHandler.doesRecordExists(newLecturer)){
        JOptionPane.showMessageDialog(null, "Record already exists", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    fileHandler.writeRecord(newLecturer);
    JOptionPane.showMessageDialog(null, "Register Succesful", "NOTICE", JOptionPane.INFORMATION_MESSAGE);
    return true;
}
}
