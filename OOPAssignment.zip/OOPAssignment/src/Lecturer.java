/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class Lecturer {
    private String lecturerID;
    private String lecturerName;
    private String lecturerPassword;
    private String lecturerGender;
    
public Lecturer (String lecturerID, String Name, String Password, String Gender){
    this.lecturerID = lecturerID;
    this.lecturerName = Name;
    this.lecturerPassword = Password;
    this.lecturerGender = Gender;
    
}

public String getLecturerID (){
    return lecturerID;
}

public String getLecturerName(){
    return lecturerName;
}

public String getLeturerPassword(){
    return lecturerPassword;
}

public String lecturerGender(){
    return lecturerGender;
}

 public boolean isValidLogin(String loginUsername, String loginPassword) {
        return this.lecturerName.equals(loginUsername) && this.lecturerPassword.equals(loginPassword);
    }

public String toString(){
    return lecturerID + ":" + lecturerName + ":" + lecturerPassword + ":" + lecturerGender;
}
}