/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.text.ParseException;
import java.util.*;
import java.text.SimpleDateFormat;
/**
 *
 * @author HP
 */
public class BookingFileHandler implements FileHandler {
    private static final String filename = "booking.txt";
    
    public void writeRecord(Booking book) throws IOException{
        try(BufferedWriter bw = new BufferedWriter(new FileWriter("booking.txt", true))){
            bw.write(book.toString());
            bw.newLine();
    } catch (IOException e) {
            throw new IOException("Error writing to the booking file: " + e.getMessage());
        }
    } //fetch all booking records from booking.txt
    public List<Booking> fetchBookingData() throws IOException{
        List<Booking> bookings = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("booking.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");  
                if (parts.length == 7) {  
                    bookings.add(new Booking(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]));
                }
            }
        }
        return bookings;
    }
    
    //Filter bookings into "current" and "past" appoinments
    public Map<String, List<Booking>> filterBookings(List<Booking> bookings) throws ParseException{
        List<Booking> currentAppointments = new ArrayList<>();
        List<Booking> pastAppointments = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();
        
        for (Booking booking : bookings){
            Date bookingDate = sdf.parse(booking.getBookDate());
            if(bookingDate.before(today)){
                pastAppointments.add(booking);
            }else{
                currentAppointments.add(booking);
            }
        }
        Map<String, List<Booking>> filteredAppointments = new HashMap<>();
        filteredAppointments.put("current",currentAppointments);
        filteredAppointments.put("past", pastAppointments);
        return filteredAppointments;
    }
    
    public boolean doesRecordExists(String completeID) throws IOException {
        List<Booking> existingSlots = fetchBookingData();
        if (existingSlots == null) {
        return false;
    }
        for(Booking existingSlot : existingSlots){
            if (existingSlot.getBookID().equals(completeID)){
                return true;
            }
        }
 return false;  
}
    
    public void updateRecord(DefaultTableModel model, String bookID, String bookDay, String bookDate, 
         String bookStartTime, String bookEndTime, String bookLocation, String bookStatus, 
         String completeID) throws IOException {
     String rec;
     int nor = model.getRowCount();
     List<String> updatedRecords = new ArrayList<>();
     
     for (int i = 0; i < nor; i++) {
         bookID = model.getValueAt(i, 0).toString();
         bookDay = model.getValueAt(i, 1).toString();
         bookDate = model.getValueAt(i, 2).toString();
         bookStartTime = model.getValueAt(i, 3).toString();
         bookEndTime = model.getValueAt(i, 4).toString();
         bookLocation = model.getValueAt(i, 5).toString();
         
         if (bookID.equals(completeID)) {
             bookStatus = "Completed";
         } else {
             bookStatus = model.getValueAt(i, 6).toString();
         }
         
         rec = bookID + ":" + bookDay + ":" + bookDate +
                 ":" + bookStartTime + ":" + bookEndTime + ":" + bookLocation + 
                 ":" + bookStatus;
         updatedRecords.add(rec);
     }
     
     try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
         for (String record : updatedRecords) {
             bw.write(record);
             bw.newLine();
         }
     }
 

    }
    public void cancelBooking(String bookID) throws IOException {
     List<Booking> bookings = fetchBookingData();
     List<String> updatedRecords = new ArrayList<>();
     
     for (Booking booking : bookings) {
         if (booking.getBookID().equals(bookID)) {
             booking.setBookStatus("Cancelled");
         }
         updatedRecords.add(booking.toString());
     }
     
     try (BufferedWriter bw = new BufferedWriter(new FileWriter("booking.txt"))) {
         for (String record : updatedRecords) {
             bw.write(record);
             bw.newLine();
         }
     }
 }

    public void rescheduleBooking(String bookID, String newDate, String newStartTime, String newEndTime) throws IOException {
     List<Booking> bookings = fetchBookingData();
     List<String> updatedRecords = new ArrayList<>();
     
     for (Booking booking : bookings) {
         if (booking.getBookID().equals(bookID)) {
             booking.setConsultDate(newDate);       
             booking.setConsultStartTime(newStartTime);  
             booking.setConsultEndTime(newEndTime);      
             booking.setBookStatus("Request Pending");  // updating the consultation information
         }
         updatedRecords.add(booking.toString());
     }
     
     try (BufferedWriter bw = new BufferedWriter(new FileWriter("booking.txt"))) {
         for (String record : updatedRecords) {
             bw.write(record);
             bw.newLine();
         }
     }
     
    
 }

     public void rescheduleRequest(String completeID, String status) throws IOException {
     List<Booking> bookings = fetchBookingData();
     List<String> updatedRecords = new ArrayList<>();
     
     for (Booking booking : bookings) {
         if (booking.getBookID().equals(completeID)) {
            
            if (status == "Approved") {
            booking.setBookStatus("Approved");

         } else if (status == "Denied") {
            booking.setBookStatus("Denied");
         }

        }
         updatedRecords.add(booking.toString());
     }
     
     try (BufferedWriter bw = new BufferedWriter(new FileWriter("booking.txt"))) {
         for (String record : updatedRecords) {
             bw.write(record);
             bw.newLine();
         }
     }
 }
    


    @Override
    public boolean doesRecordExists() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void readRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void writeRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void updateRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

