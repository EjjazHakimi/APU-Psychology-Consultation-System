/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class Feedback extends Booking {
    private String feedbackID;
    private String feedbackLecturer;
    private String feedbackStudent;
    
public Feedback (String feedbackID, String bookDay, String bookDate, String bookStartTime, String bookEndTime, String bookLocation, String bookStatus,
         String feedbackLecturer, String feedbackStudent) {

super("bookID", bookDay, bookDate, bookStartTime, bookEndTime, bookLocation, bookStatus);

this.feedbackID = feedbackID;
this.feedbackLecturer = feedbackLecturer;
this.feedbackStudent = feedbackStudent;
}

public String getFeedbackID(){
    return feedbackID;
}

public String getFeedbackLecturer(){
    return feedbackLecturer;
}

public String getFeedbackStudent(){
    return feedbackStudent;
}

public void setFeedbackStudent(String completeStudentFeedback){
    this.feedbackStudent = completeStudentFeedback;
}

    @Override
    public String toString(){
    return feedbackID + ":" + getBookDay() + ":" + getBookDate() + ":" + getBookStartTime() 
            + ":" + getBookEndTime() + ":" + getBookLocation() + ":" + getBookStatus() +
            ":" + feedbackLecturer + ":" + feedbackStudent;
}
}