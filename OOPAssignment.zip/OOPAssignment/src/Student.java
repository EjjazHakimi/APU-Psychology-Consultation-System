/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class Student {
    private String studentID;
    private String studentName;
    private String studentPassword;
    private String studentGender;
    
public Student(String studentID, String Name, String Password, String Gender){
    this.studentID = studentID;
    this.studentName = Name;
    this.studentPassword = Password;
    this.studentGender = Gender;
    
}

public String getStudentID(){
    return studentID;
}

public String getStudentName(){
    return studentName;
}

public String getStudentPassword(){
    return studentPassword;
}

public String getStudentGender(){
    return studentGender;
}

public boolean isValidLogin(String loginUsername, String loginPassword) {
        return this.studentName.equals(loginUsername) && this.studentPassword.equals(loginPassword);
}

public String toString(){
    return studentID + ":" + studentName + ":" + studentPassword + ":" + studentGender;
}
}