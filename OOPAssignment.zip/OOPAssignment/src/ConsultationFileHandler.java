
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class ConsultationFileHandler implements FileHandler {
     private static final String filename = "consultation.txt";
    
public void writeRecord(ConsultationSlot consultation) throws IOException {
    try(BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))){
        bw.write(consultation.toString());
        bw.newLine();
    }
}

public void updateRecord(DefaultTableModel model, String consultID, String consultDay, 
        String consultDate, String consultStartTime, String consultEndTime, String consultLocation) throws IOException, ParseException {
    
    String rec;
    SetConsultation consult = new SetConsultation();
    int nor = model.getRowCount();
    boolean validInput = true;
     

    for (int i = 0; i < nor; i ++){
        
        consultID = model.getValueAt(i, 0).toString();
        consultDay = model.getValueAt(i, 1).toString();
        consultDate = model.getValueAt(i, 2).toString();
        consultStartTime = model.getValueAt(i, 3).toString();
        consultEndTime = model.getValueAt(i, 4).toString();
        consultLocation = model.getValueAt(i, 5).toString();
        
        if(consult.hasDatePassed(consultDate)){
            JOptionPane.showMessageDialog(null, "Date has passed", "ERROR", JOptionPane.ERROR_MESSAGE);
            validInput = false;
            break;
                       
        } else if(consult.hasTimePassed(consultDate, consultStartTime)){
            JOptionPane.showMessageDialog(null, "Time has passed", "ERROR", JOptionPane.ERROR_MESSAGE);
            validInput = false;
            break;
            
        } else if(consultStartTime.equals(consultEndTime)){
            JOptionPane.showMessageDialog(null, "Time is the same", "ERROR", JOptionPane.ERROR_MESSAGE);
            validInput = false;
            break;
            
        } else if(!consult.isTimeValid(consultStartTime, consultEndTime)){
            validInput = false;
                break;
                
        } 
    }

    if(validInput){
    
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
        for(int i = 0; i < nor; i ++){
            

        rec = model.getValueAt(i, 0).toString() + ":" + model.getValueAt(i, 1).toString() + ":" + model.getValueAt(i, 2).toString() +
                ":" + model.getValueAt(i, 3).toString() + ":" + model.getValueAt(i, 4).toString() + ":" + model.getValueAt(i, 5).toString();
        
        bw.write(rec);
        bw.newLine();
        
    } 
    } catch (IOException ex) {
            Logger.getLogger(ConsultationScreen.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    ConsultationSlot [] consultSlot = consult.loadConsultationSlot();
    
    model.setRowCount(0);
    
    for (ConsultationSlot slot : consultSlot) {
        if (slot != null) {
            Object[] rowData = {
                slot.getConsultID(),
                slot.getConsultDay(),
                slot.getConsultDate(),
                slot.getConsultStartTime(),
                slot.getConsultEndTime(),
                slot.getConsultLocation()
            };
            if (!consult.doesConsultIDExist(model, slot.getConsultID())) {
                model.addRow(rowData);
            }
        }
    }


    JOptionPane.showMessageDialog(null, "File Updated", "NOTICE", JOptionPane.INFORMATION_MESSAGE);
}
}

public void deleteRecord(String deleteID) throws IOException{
    
    File current = new File(filename);
    File temp = new File("deleteTemp.txt");
 
    BufferedReader br = new BufferedReader(new FileReader(current));
    BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
        
        String currentLine;
        boolean recordFound = false;
        
        while ((currentLine = br.readLine()) != null){
            
            String [] parts = currentLine.split(":");
            
            if((parts.length) > 0 && (!parts[0].equals(deleteID))){
                bw.write(currentLine);
                bw.newLine();
                
            } else {
                recordFound = true;
            }
    }
        br.close();
        bw.close();
        
        if (recordFound) {
            if (current.delete()) {
                temp.renameTo(current);
                JOptionPane.showMessageDialog(null, "Consultation Record Deleted", "NOTICE", JOptionPane.INFORMATION_MESSAGE);

            } else {
                JOptionPane.showMessageDialog(null, "Record Deletion Failed", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        
    } else {
            JOptionPane.showMessageDialog(null, "Record Not Found", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
}

    @Override
    public boolean doesRecordExists() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void readRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void writeRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void updateRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}




