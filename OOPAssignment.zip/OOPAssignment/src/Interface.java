/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
interface FileHandler {
    public boolean doesRecordExists();
    public void readRecord();
    public void writeRecord();
    public void deleteRecord();
    public void updateRecord();
}
