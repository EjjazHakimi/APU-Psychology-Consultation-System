/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Booking {
    private String bookID;
    private String bookDay;
    private String bookDate;
    private String bookStartTime;
    private String bookEndTime;
    private String bookLocation;
    private String bookStatus;
    
public Booking(String bookID, String bookDay, String bookDate, String bookStartTime, String bookEndTime, String bookLocation, String bookStatus){
    this.bookID = bookID;
    this.bookDay = bookDay;
    this.bookDate = bookDate;
    this.bookStartTime = bookStartTime;
    this.bookEndTime = bookEndTime;
    this.bookLocation = bookLocation;
    this.bookStatus = bookStatus;
}
public String getBookID(){
    return bookID;
}

public String getBookDay(){
    return bookDay;
}
public String getBookDate(){
    return bookDate;
}
public String getBookStartTime(){
    return bookStartTime;
}
public String getBookEndTime(){
    return bookEndTime;
}
public String getBookLocation(){
    return bookLocation;
}
public String getBookStatus(){
    return bookStatus;
}

public void setConsultDate(String newDate){
    this.bookDate = newDate;
}
public void setConsultStartTime(String newStartTime){
    this.bookStartTime = newStartTime;
}
public void setConsultEndTime(String newEndTime){
    this.bookEndTime = newEndTime;
}
public void setBookStatus(String newStatus){
    this.bookStatus = newStatus;
}
public String toString(){
        return bookID + ":" + bookDay + ":" + bookDate + ":" + bookStartTime + ":" + 
               bookEndTime + ":" + bookLocation + ":" + bookStatus;
    }
}