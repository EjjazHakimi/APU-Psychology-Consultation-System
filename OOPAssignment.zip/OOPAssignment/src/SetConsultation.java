
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class SetConsultation {
    private static final String filename = "consultation.txt";
    private ConsultationFileHandler fileHandler;
    private static final int maxCount = 100;
    
public SetConsultation(){
    this.fileHandler = new ConsultationFileHandler();
}

public boolean setConsultation(String consultDay, String consultDate, String consultStartTime, String consultEndTime, String consultLocation) throws IOException{
    if (consultDay.isEmpty() || consultDate.isEmpty() || consultStartTime.isEmpty() || consultEndTime.isEmpty() || consultLocation.isEmpty()){
        
        JOptionPane.showMessageDialog(null, "One or more mandatory fields is empty", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    Random rand = new Random();
    String consultID = "CN"+rand.nextInt(1000);
    
    ConsultationSlot newConsultSlot = new ConsultationSlot(consultID, consultDay, consultDate, consultStartTime, consultEndTime, consultLocation);
 
    fileHandler.writeRecord(newConsultSlot);
    JOptionPane.showMessageDialog(null, "Consultation succesfully set", "NOTICE", JOptionPane.INFORMATION_MESSAGE);
    return true;    
    }

public ConsultationSlot [] loadConsultationSlot() throws IOException {
    ConsultationSlot [] consultSlot = new ConsultationSlot[maxCount];
    int index = 0;
    
    try(BufferedReader br = new BufferedReader(new FileReader("consultation.txt"))){
        String line;
        while ((line = br.readLine()) != null && index < maxCount){
            String [] consultSlotRecord = line.split(":");
            
            if (line.trim().isEmpty()) {
                continue;
             }
            
            String consultID = consultSlotRecord[0];
            String consultDay = consultSlotRecord[1];
            String consultDate = consultSlotRecord[2];
            String consultStartTime = consultSlotRecord[3];
            String consultEndTime = consultSlotRecord[4];
            String consultLocation = consultSlotRecord[5];
            
            consultSlot[index++] = new ConsultationSlot(consultID, consultDay, 
                    consultDate, consultStartTime, consultEndTime, consultLocation);
        }
            
        }
    return consultSlot;
        
    }


public boolean doesConsultIDExist(DefaultTableModel model, String consultID) {
    for (int i = 0; i < model.getRowCount(); i++) {
        if (model.getValueAt(i, 0).equals(consultID)) { 
            return true;
        }
    }
    return false;
}

public boolean hasDatePassed(String consultDate) {
    try {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate inputDate = LocalDate.parse(consultDate, dateFormatter);
        LocalDate currentDate = LocalDate.now();
        
        if(inputDate.isBefore(currentDate)){
            return true;
        }
        
    } catch (DateTimeParseException e) {
        JOptionPane.showMessageDialog(null, "Invalid date format: " + consultDate + " Format should be yyyy-MM-dd", "ERROR", JOptionPane.ERROR_MESSAGE);

        return true;
    }
    return false;
}
public boolean hasTimePassed(String consultDate, String consultStartTime) {
    try {
        LocalDate inputDate = LocalDate.parse(consultDate);
        LocalDate currentDate = LocalDate.now();

        if (inputDate.isEqual(currentDate)) {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH.mm");
        LocalTime inputTime = LocalTime.parse(consultStartTime, timeFormatter);
        LocalTime currentTime = LocalTime.now();
        
        if(inputTime.isBefore(currentTime)){
            return true;
        }
        
        }return false;
        
        
    } catch (DateTimeParseException e) {
        JOptionPane.showMessageDialog(null, "Invalid time format: " + consultStartTime + " Format should be HH.mm", "ERROR", JOptionPane.ERROR_MESSAGE);
        return true; 
    }
}
public boolean doesRecordExists(ConsultationSlot newConsultation) throws IOException {
        ConsultationSlot[] existingSlots = loadConsultationSlot();

        for (ConsultationSlot existingSlot : existingSlots) {
            if (existingSlot != null
                    && existingSlot.getConsultID().equals(newConsultation.getConsultID())
                    || (existingSlot != null && existingSlot.getConsultDate().equals(newConsultation.getConsultDate())
                    && existingSlot.getConsultStartTime().equals(newConsultation.getConsultStartTime()))) {
                return true;
            }
        }

    return false;
}

public boolean isTimeValid(String consultStartTime, String consultEndTime) throws ParseException{
    SimpleDateFormat time = new SimpleDateFormat("HH.mm");
    Date startTime = time.parse(consultStartTime);
    Date endTime = time.parse(consultEndTime);
    
    if(startTime.after(endTime)){
        JOptionPane.showMessageDialog(null, "Invalid Time Range", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    return true;
}
}
