
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class FeedbackFileHandler implements FileHandler {
     private static final String filename = "feedback.txt";
    
     public void writeRecord(DefaultTableModel model, int row, String completeLecturerFeedback, String completeStudentFeedback, String feedbackID) throws IOException{
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))){
            
            String bookDay = model.getValueAt(row, 1).toString();
            String bookDate = model.getValueAt(row, 2).toString();
            String bookStartTime = model.getValueAt(row, 3).toString();
            String bookEndTime = model.getValueAt(row, 4).toString();
            String bookLocation = model.getValueAt(row, 5).toString();
            String boookStatus = model.getValueAt(row, 6).toString();
            String feedbackLecturer = completeLecturerFeedback;
            String feedbackStudent = completeStudentFeedback;
            
            Feedback feedback = new Feedback(feedbackID, bookDay, bookDate, bookStartTime,
            bookEndTime, bookLocation, boookStatus, feedbackLecturer, feedbackStudent);
            
            bw.write(feedback.toString());
            bw.newLine();
    } catch (IOException e) {
            throw new IOException("Error writing to the feedback file: " + e.getMessage());
        }
    }
   
     
      public List<Feedback> fetchFeedbackData() throws IOException{
        List<Feedback> feedbacks = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");  
                if (parts.length == 9) {  
                    feedbacks.add(new Feedback(parts[0], parts[1], parts[2], parts[3], 
                            parts[4], parts[5], parts[6], parts[7], parts[8]));
                }
            }
        }
        return feedbacks;
    }
     
     public boolean doesRecordExists(String feedbackID) throws IOException {
         List<Feedback> existingSlots = fetchFeedbackData();
         if (existingSlots == null) {
        return false;
     }  
         for(Feedback existingSlot : existingSlots){
            if (existingSlot.getFeedbackID().equals(feedbackID)){
                return true;
     }
            }
           return false;
     } 
     

  

    @Override
    public void readRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    @Override
    public void deleteRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void updateRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void writeRecord() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean doesRecordExists() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
