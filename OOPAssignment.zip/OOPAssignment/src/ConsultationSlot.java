/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class ConsultationSlot {
    private String consultID;
    private String consultDay;
    private String consultDate;
    private String consultStartTime;
    private String consultEndTime;
    private String consultLocation;

public ConsultationSlot(String consultID, String consultDay, String consultDate, 
        String consultStartTime, String consultEndTime, String consultLocation){
    this.consultID = consultID;
    this.consultDay = consultDay;
    this.consultDate = consultDate;
    this.consultStartTime = consultStartTime;
    this.consultEndTime = consultEndTime;
    this.consultLocation = consultLocation;
}

public String getConsultID(){
    return consultID;
}

public String getConsultDay(){
    return consultDay;
}

public String getConsultDate(){
    return consultDate;
}

public String getConsultStartTime(){
    return consultStartTime;
}

public String getConsultEndTime(){
    return consultEndTime;
}

public String getConsultLocation(){
    return consultLocation;
}

    @Override
    public String toString(){
    return consultID + ":" + consultDay + ":" + consultDate + ":" + consultStartTime 
            + ":" + consultEndTime + ":" +consultLocation;
}
}
