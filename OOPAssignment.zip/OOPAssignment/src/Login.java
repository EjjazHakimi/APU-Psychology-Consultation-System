
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ejjaz
 */
public class Login {
    private static final int maxCount = 100;

    
public Lecturer [] loadLecturers() throws IOException {
    Lecturer [] lecturers = new Lecturer[maxCount];
    int index = 0;
    
    try(BufferedReader br = new BufferedReader(new FileReader("lecturer.txt"))){
        String line;
        while ((line = br.readLine()) != null && index < maxCount){
            String [] lecturerRecord = line.split(":");
            String lecturerID = lecturerRecord[0];
            String lecturerName = lecturerRecord[1];
            String lecturerPassword = lecturerRecord[2];
            String lecturerGender = lecturerRecord[3];
            
            lecturers[index++] = new Lecturer(lecturerID, lecturerName, lecturerPassword, lecturerGender);
        }
            
        }
    return lecturers;
                
    }

public Student [] loadStudents() throws IOException {
    Student [] students = new Student[maxCount];
    int index = 0;
    
    try(BufferedReader br = new BufferedReader(new FileReader("student.txt"))){
        String line;
        while ((line = br.readLine()) != null && index < maxCount){
            String [] studentRecord = line.split(":");
            String studentID = studentRecord[0];
            String studentName = studentRecord[1];
            String studentPassword = studentRecord[2];
            String studentGender = studentRecord[3];
            
            students[index++] = new Student(studentID, studentName, studentPassword, studentGender);
        }
            
        }
    return students;
                
    }
 public boolean isValidLoginLecturer(String loginUsername, String loginPassword) throws IOException {
     Lecturer[] lecturers = loadLecturers();
     for (Lecturer lecturer : lecturers) {
         if (lecturer != null && lecturer.isValidLogin(loginUsername, loginPassword)) {
             return true;
         }
     }
     return false;
 }
 
 public boolean isValidLoginStudent(String loginUsername, String loginPassword) throws IOException {
     Student [] students = loadStudents();
     for (Student student : students){
         if (student != null && student.isValidLogin(loginUsername, loginPassword)){
             return true;
         }
     }
        return false;
    }
}
    

